class Item < ApplicationRecord
  require 'carrierwave/orm/activerecord'
  has_many :comments
  belongs_to :user
  mount_uploader :image_url, ImageUploader

  has_many :user_items
  has_many :items, through: :user_items
end
