class ItemsController < ApplicationController
  before_action :authenticate_user!, only: [:edit, :show, :destroy, :create]
  before_action :set_item, only: [:edit, :show, :update, :destroy]

  def index
    @items = Item.all
  end

  def new
    @item = Item.new
  end

  def create
    @item = current_user.items.new(item_params)
    respond_to do |format|
      if @item.save
        format.html{redirect_to items_path, notice:"성공적으로 생성되었습니다!"}
      else
        format.html{render :new}
      end
    end
  end

  def show
  end


  def edit

  end

  def update
    respond_to do |format|
      if @item.update(item_params)
        format.html{redirect_to items_path, notice:"성공적으로 수정되었습니다!"}
      else
        format.html{render :edit}
      end
    end
  end

  def destroy
    @item.destroy
    redirect_to items_path
  end

  private
  def set_item
    @item = Item.find(params[:id])
  end

  # white list
  def item_params
    params.require(:item).permit(:title, :content, :user_id, :image_url)
  end

end
