class UserItemsController < ApplicationController
  before_action :authenticate_user!, only: [:index, :destroy, :create]

  def index
    @useritems = UserItem.all
  end

  def create
    UserItem.find_or_create_by!(item_id: params[:item_id], user_id: current_user.id)
    redirect_back(fallback_location: root_path)

  end

  def destroy
    @useritem = UserItem.find_by(item_id: params[:item_id], user_id: current_user.id)
    @useritem.destroy
    redirect_back(fallback_location: root_path)

  end




end
