Rails.application.routes.draw do

  get 'user_items/index', as:'useritems_index'
  post 'user_items/create'
  get 'user_item/:item_id/destroy', to: 'user_items#destroy', as: :user_item_destroy

  get 'comments/create'
  get 'comments/destroy'
  root "items#index"

  # comment는 item에 속해 있음
  resources :items, controller: "items" do
    resources :comments, only: [:create, :destroy]
  end
  devise_for :users, path: 'user', path_names: {sign_in: 'login', sign_out: 'logout', sign_up: 'join' }
  #경로 이름 바꾸고 싶을때


  # get 'items/index'
  # get 'items/new'
  # get 'item/show', as: 'items_show'
  # post 'items/create', as: 'items_create'
  # get 'items/destroy/:item_id' => 'items#destroy', as: 'items_destroy'
  # get 'items/edit/:item_id' => 'items#edit', as: 'items_edit'
  # patch 'items/update/:item_id' => 'items#update', as: 'items_update'
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
